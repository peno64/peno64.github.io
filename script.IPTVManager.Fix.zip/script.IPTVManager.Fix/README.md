# Fix IPTV Manager configuration
Fix IPTV Manager configuration

# Installation in kodi:
Via repository https://peno64.github.io/repository.peno64/

Addon is installed and can be found in Add-ons under section Program add-ons
